﻿namespace Console.UC
{
    partial class UCRoomManageValue
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblId = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.lblNo = new System.Windows.Forms.Label();
            this.lblBed = new System.Windows.Forms.Label();
            this.lblPerson = new System.Windows.Forms.Label();
            this.lblArea = new System.Windows.Forms.Label();
            this.lblPrice = new System.Windows.Forms.Label();
            this.btnMore = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Shapes1 = new Guna.UI2.WinForms.Guna2Shapes();
            this.guna2Shapes2 = new Guna.UI2.WinForms.Guna2Shapes();
            this.guna2Shapes3 = new Guna.UI2.WinForms.Guna2Shapes();
            this.guna2Shapes4 = new Guna.UI2.WinForms.Guna2Shapes();
            this.guna2Shapes5 = new Guna.UI2.WinForms.Guna2Shapes();
            this.guna2Shapes6 = new Guna.UI2.WinForms.Guna2Shapes();
            this.guna2Shapes7 = new Guna.UI2.WinForms.Guna2Shapes();
            this.cbCheck = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.ccValue = new Guna.UI2.WinForms.Guna2ContainerControl();
            this.guna2Shapes8 = new Guna.UI2.WinForms.Guna2Shapes();
            this.lblType = new System.Windows.Forms.Label();
            this.lblRoomId = new System.Windows.Forms.Label();
            this.ccValue.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblId
            // 
            this.lblId.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblId.AutoSize = true;
            this.lblId.BackColor = System.Drawing.Color.Transparent;
            this.lblId.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblId.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(135)))), ((int)(((byte)(145)))), ((int)(((byte)(180)))));
            this.lblId.Location = new System.Drawing.Point(55, 14);
            this.lblId.Name = "lblId";
            this.lblId.Size = new System.Drawing.Size(43, 17);
            this.lblId.TabIndex = 0;
            this.lblId.Text = "label1";
            // 
            // lblName
            // 
            this.lblName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblName.AutoSize = true;
            this.lblName.BackColor = System.Drawing.Color.Transparent;
            this.lblName.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(135)))), ((int)(((byte)(145)))), ((int)(((byte)(180)))));
            this.lblName.Location = new System.Drawing.Point(226, 14);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(43, 17);
            this.lblName.TabIndex = 1;
            this.lblName.Text = "label1";
            // 
            // lblNo
            // 
            this.lblNo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblNo.AutoSize = true;
            this.lblNo.BackColor = System.Drawing.Color.Transparent;
            this.lblNo.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(135)))), ((int)(((byte)(145)))), ((int)(((byte)(180)))));
            this.lblNo.Location = new System.Drawing.Point(740, 14);
            this.lblNo.Name = "lblNo";
            this.lblNo.Size = new System.Drawing.Size(43, 17);
            this.lblNo.TabIndex = 2;
            this.lblNo.Text = "label1";
            // 
            // lblBed
            // 
            this.lblBed.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblBed.AutoSize = true;
            this.lblBed.BackColor = System.Drawing.Color.Transparent;
            this.lblBed.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBed.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(135)))), ((int)(((byte)(145)))), ((int)(((byte)(180)))));
            this.lblBed.Location = new System.Drawing.Point(840, 14);
            this.lblBed.Name = "lblBed";
            this.lblBed.Size = new System.Drawing.Size(43, 17);
            this.lblBed.TabIndex = 3;
            this.lblBed.Text = "label1";
            // 
            // lblPerson
            // 
            this.lblPerson.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblPerson.AutoSize = true;
            this.lblPerson.BackColor = System.Drawing.Color.Transparent;
            this.lblPerson.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPerson.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(135)))), ((int)(((byte)(145)))), ((int)(((byte)(180)))));
            this.lblPerson.Location = new System.Drawing.Point(940, 14);
            this.lblPerson.Name = "lblPerson";
            this.lblPerson.Size = new System.Drawing.Size(43, 17);
            this.lblPerson.TabIndex = 4;
            this.lblPerson.Text = "label1";
            // 
            // lblArea
            // 
            this.lblArea.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblArea.AutoSize = true;
            this.lblArea.BackColor = System.Drawing.Color.Transparent;
            this.lblArea.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblArea.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(135)))), ((int)(((byte)(145)))), ((int)(((byte)(180)))));
            this.lblArea.Location = new System.Drawing.Point(1140, 14);
            this.lblArea.Name = "lblArea";
            this.lblArea.Size = new System.Drawing.Size(43, 17);
            this.lblArea.TabIndex = 6;
            this.lblArea.Text = "label1";
            // 
            // lblPrice
            // 
            this.lblPrice.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblPrice.AutoSize = true;
            this.lblPrice.BackColor = System.Drawing.Color.Transparent;
            this.lblPrice.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrice.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(135)))), ((int)(((byte)(145)))), ((int)(((byte)(180)))));
            this.lblPrice.Location = new System.Drawing.Point(1040, 14);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(43, 17);
            this.lblPrice.TabIndex = 5;
            this.lblPrice.Text = "label1";
            // 
            // btnMore
            // 
            this.btnMore.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnMore.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnMore.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnMore.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnMore.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnMore.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnMore.ForeColor = System.Drawing.Color.White;
            this.btnMore.Location = new System.Drawing.Point(1244, 7);
            this.btnMore.Name = "btnMore";
            this.btnMore.Size = new System.Drawing.Size(38, 30);
            this.btnMore.TabIndex = 8;
            this.btnMore.Text = "...";
            // 
            // guna2Shapes1
            // 
            this.guna2Shapes1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.guna2Shapes1.BackColor = System.Drawing.Color.Transparent;
            this.guna2Shapes1.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.guna2Shapes1.LineOrientation = System.Windows.Forms.Orientation.Vertical;
            this.guna2Shapes1.LineThickness = 4;
            this.guna2Shapes1.Location = new System.Drawing.Point(822, 7);
            this.guna2Shapes1.Name = "guna2Shapes1";
            this.guna2Shapes1.PolygonSkip = 1;
            this.guna2Shapes1.Rotate = 0F;
            this.guna2Shapes1.Shape = Guna.UI2.WinForms.Enums.ShapeType.Line;
            this.guna2Shapes1.Size = new System.Drawing.Size(12, 33);
            this.guna2Shapes1.TabIndex = 9;
            this.guna2Shapes1.Text = "guna2Shapes1";
            this.guna2Shapes1.Zoom = 80;
            // 
            // guna2Shapes2
            // 
            this.guna2Shapes2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.guna2Shapes2.BackColor = System.Drawing.Color.Transparent;
            this.guna2Shapes2.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.guna2Shapes2.LineOrientation = System.Windows.Forms.Orientation.Vertical;
            this.guna2Shapes2.LineThickness = 4;
            this.guna2Shapes2.Location = new System.Drawing.Point(722, 6);
            this.guna2Shapes2.Name = "guna2Shapes2";
            this.guna2Shapes2.PolygonSkip = 1;
            this.guna2Shapes2.Rotate = 0F;
            this.guna2Shapes2.Shape = Guna.UI2.WinForms.Enums.ShapeType.Line;
            this.guna2Shapes2.Size = new System.Drawing.Size(12, 33);
            this.guna2Shapes2.TabIndex = 10;
            this.guna2Shapes2.Text = "guna2Shapes2";
            this.guna2Shapes2.Zoom = 80;
            // 
            // guna2Shapes3
            // 
            this.guna2Shapes3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.guna2Shapes3.BackColor = System.Drawing.Color.Transparent;
            this.guna2Shapes3.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.guna2Shapes3.LineOrientation = System.Windows.Forms.Orientation.Vertical;
            this.guna2Shapes3.LineThickness = 4;
            this.guna2Shapes3.Location = new System.Drawing.Point(208, 6);
            this.guna2Shapes3.Name = "guna2Shapes3";
            this.guna2Shapes3.PolygonSkip = 1;
            this.guna2Shapes3.Rotate = 0F;
            this.guna2Shapes3.Shape = Guna.UI2.WinForms.Enums.ShapeType.Line;
            this.guna2Shapes3.Size = new System.Drawing.Size(12, 33);
            this.guna2Shapes3.TabIndex = 11;
            this.guna2Shapes3.Text = "guna2Shapes3";
            this.guna2Shapes3.Zoom = 80;
            // 
            // guna2Shapes4
            // 
            this.guna2Shapes4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.guna2Shapes4.BackColor = System.Drawing.Color.Transparent;
            this.guna2Shapes4.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.guna2Shapes4.LineOrientation = System.Windows.Forms.Orientation.Vertical;
            this.guna2Shapes4.LineThickness = 4;
            this.guna2Shapes4.Location = new System.Drawing.Point(37, 6);
            this.guna2Shapes4.Name = "guna2Shapes4";
            this.guna2Shapes4.PolygonSkip = 1;
            this.guna2Shapes4.Rotate = 0F;
            this.guna2Shapes4.Shape = Guna.UI2.WinForms.Enums.ShapeType.Line;
            this.guna2Shapes4.Size = new System.Drawing.Size(12, 33);
            this.guna2Shapes4.TabIndex = 12;
            this.guna2Shapes4.Text = "guna2Shapes4";
            this.guna2Shapes4.Zoom = 80;
            // 
            // guna2Shapes5
            // 
            this.guna2Shapes5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.guna2Shapes5.BackColor = System.Drawing.Color.Transparent;
            this.guna2Shapes5.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.guna2Shapes5.LineOrientation = System.Windows.Forms.Orientation.Vertical;
            this.guna2Shapes5.LineThickness = 4;
            this.guna2Shapes5.Location = new System.Drawing.Point(922, 6);
            this.guna2Shapes5.Name = "guna2Shapes5";
            this.guna2Shapes5.PolygonSkip = 1;
            this.guna2Shapes5.Rotate = 0F;
            this.guna2Shapes5.Shape = Guna.UI2.WinForms.Enums.ShapeType.Line;
            this.guna2Shapes5.Size = new System.Drawing.Size(12, 33);
            this.guna2Shapes5.TabIndex = 13;
            this.guna2Shapes5.Text = "guna2Shapes5";
            this.guna2Shapes5.Zoom = 80;
            // 
            // guna2Shapes6
            // 
            this.guna2Shapes6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.guna2Shapes6.BackColor = System.Drawing.Color.Transparent;
            this.guna2Shapes6.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.guna2Shapes6.LineOrientation = System.Windows.Forms.Orientation.Vertical;
            this.guna2Shapes6.LineThickness = 4;
            this.guna2Shapes6.Location = new System.Drawing.Point(1022, 5);
            this.guna2Shapes6.Name = "guna2Shapes6";
            this.guna2Shapes6.PolygonSkip = 1;
            this.guna2Shapes6.Rotate = 0F;
            this.guna2Shapes6.Shape = Guna.UI2.WinForms.Enums.ShapeType.Line;
            this.guna2Shapes6.Size = new System.Drawing.Size(12, 33);
            this.guna2Shapes6.TabIndex = 14;
            this.guna2Shapes6.Text = "guna2Shapes6";
            this.guna2Shapes6.Zoom = 80;
            // 
            // guna2Shapes7
            // 
            this.guna2Shapes7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.guna2Shapes7.BackColor = System.Drawing.Color.Transparent;
            this.guna2Shapes7.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.guna2Shapes7.LineOrientation = System.Windows.Forms.Orientation.Vertical;
            this.guna2Shapes7.LineThickness = 4;
            this.guna2Shapes7.Location = new System.Drawing.Point(1122, 6);
            this.guna2Shapes7.Name = "guna2Shapes7";
            this.guna2Shapes7.PolygonSkip = 1;
            this.guna2Shapes7.Rotate = 0F;
            this.guna2Shapes7.Shape = Guna.UI2.WinForms.Enums.ShapeType.Line;
            this.guna2Shapes7.Size = new System.Drawing.Size(12, 33);
            this.guna2Shapes7.TabIndex = 15;
            this.guna2Shapes7.Text = "guna2Shapes7";
            this.guna2Shapes7.Zoom = 80;
            // 
            // cbCheck
            // 
            this.cbCheck.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cbCheck.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cbCheck.CheckedState.BorderRadius = 2;
            this.cbCheck.CheckedState.BorderThickness = 0;
            this.cbCheck.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cbCheck.Location = new System.Drawing.Point(11, 12);
            this.cbCheck.Name = "cbCheck";
            this.cbCheck.Size = new System.Drawing.Size(20, 20);
            this.cbCheck.TabIndex = 16;
            this.cbCheck.Text = "guna2CustomCheckBox1";
            this.cbCheck.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.cbCheck.UncheckedState.BorderRadius = 2;
            this.cbCheck.UncheckedState.BorderThickness = 0;
            this.cbCheck.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(231)))), ((int)(((byte)(255)))));
            // 
            // ccValue
            // 
            this.ccValue.BackColor = System.Drawing.Color.Transparent;
            this.ccValue.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(135)))), ((int)(((byte)(145)))), ((int)(((byte)(180)))));
            this.ccValue.BorderThickness = 1;
            this.ccValue.Controls.Add(this.lblRoomId);
            this.ccValue.Controls.Add(this.guna2Shapes8);
            this.ccValue.Controls.Add(this.lblType);
            this.ccValue.Controls.Add(this.cbCheck);
            this.ccValue.Controls.Add(this.guna2Shapes7);
            this.ccValue.Controls.Add(this.guna2Shapes6);
            this.ccValue.Controls.Add(this.guna2Shapes5);
            this.ccValue.Controls.Add(this.guna2Shapes4);
            this.ccValue.Controls.Add(this.guna2Shapes3);
            this.ccValue.Controls.Add(this.guna2Shapes2);
            this.ccValue.Controls.Add(this.guna2Shapes1);
            this.ccValue.Controls.Add(this.btnMore);
            this.ccValue.Controls.Add(this.lblArea);
            this.ccValue.Controls.Add(this.lblPrice);
            this.ccValue.Controls.Add(this.lblPerson);
            this.ccValue.Controls.Add(this.lblBed);
            this.ccValue.Controls.Add(this.lblNo);
            this.ccValue.Controls.Add(this.lblName);
            this.ccValue.Controls.Add(this.lblId);
            this.ccValue.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ccValue.Location = new System.Drawing.Point(0, 0);
            this.ccValue.Name = "ccValue";
            this.ccValue.Size = new System.Drawing.Size(1294, 46);
            this.ccValue.TabIndex = 17;
            this.ccValue.Text = "guna2ContainerControl1";
            // 
            // guna2Shapes8
            // 
            this.guna2Shapes8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.guna2Shapes8.BackColor = System.Drawing.Color.Transparent;
            this.guna2Shapes8.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.guna2Shapes8.LineOrientation = System.Windows.Forms.Orientation.Vertical;
            this.guna2Shapes8.LineThickness = 4;
            this.guna2Shapes8.Location = new System.Drawing.Point(570, 7);
            this.guna2Shapes8.Name = "guna2Shapes8";
            this.guna2Shapes8.PolygonSkip = 1;
            this.guna2Shapes8.Rotate = 0F;
            this.guna2Shapes8.Shape = Guna.UI2.WinForms.Enums.ShapeType.Line;
            this.guna2Shapes8.Size = new System.Drawing.Size(12, 33);
            this.guna2Shapes8.TabIndex = 18;
            this.guna2Shapes8.Text = "guna2Shapes8";
            this.guna2Shapes8.Zoom = 80;
            // 
            // lblType
            // 
            this.lblType.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblType.AutoSize = true;
            this.lblType.BackColor = System.Drawing.Color.Transparent;
            this.lblType.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblType.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(135)))), ((int)(((byte)(145)))), ((int)(((byte)(180)))));
            this.lblType.Location = new System.Drawing.Point(588, 15);
            this.lblType.Name = "lblType";
            this.lblType.Size = new System.Drawing.Size(43, 17);
            this.lblType.TabIndex = 17;
            this.lblType.Text = "label1";
            // 
            // lblRoomId
            // 
            this.lblRoomId.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblRoomId.AutoSize = true;
            this.lblRoomId.BackColor = System.Drawing.Color.Transparent;
            this.lblRoomId.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRoomId.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(135)))), ((int)(((byte)(145)))), ((int)(((byte)(180)))));
            this.lblRoomId.Location = new System.Drawing.Point(1189, 13);
            this.lblRoomId.Name = "lblRoomId";
            this.lblRoomId.Size = new System.Drawing.Size(54, 17);
            this.lblRoomId.TabIndex = 19;
            this.lblRoomId.Text = "RoomId";
            this.lblRoomId.Visible = false;
            // 
            // UCRoomManageValue
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.ccValue);
            this.Name = "UCRoomManageValue";
            this.Size = new System.Drawing.Size(1294, 46);
            this.ccValue.ResumeLayout(false);
            this.ccValue.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblId;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblNo;
        private System.Windows.Forms.Label lblBed;
        private System.Windows.Forms.Label lblPerson;
        private System.Windows.Forms.Label lblArea;
        private System.Windows.Forms.Label lblPrice;
        private Guna.UI2.WinForms.Guna2Button btnMore;
        private Guna.UI2.WinForms.Guna2Shapes guna2Shapes1;
        private Guna.UI2.WinForms.Guna2Shapes guna2Shapes2;
        private Guna.UI2.WinForms.Guna2Shapes guna2Shapes3;
        private Guna.UI2.WinForms.Guna2Shapes guna2Shapes4;
        private Guna.UI2.WinForms.Guna2Shapes guna2Shapes5;
        private Guna.UI2.WinForms.Guna2Shapes guna2Shapes6;
        private Guna.UI2.WinForms.Guna2Shapes guna2Shapes7;
        private Guna.UI2.WinForms.Guna2CustomCheckBox cbCheck;
        private Guna.UI2.WinForms.Guna2ContainerControl ccValue;
        private Guna.UI2.WinForms.Guna2Shapes guna2Shapes8;
        private System.Windows.Forms.Label lblType;
        private System.Windows.Forms.Label lblRoomId;
    }
}
