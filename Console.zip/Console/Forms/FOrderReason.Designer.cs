﻿namespace Console
{
    partial class FOrderReason
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelSignIn = new Guna.UI2.WinForms.Guna2Panel();
            this.rdReason6 = new Guna.UI2.WinForms.Guna2RadioButton();
            this.rdReason5 = new Guna.UI2.WinForms.Guna2RadioButton();
            this.rdReason4 = new Guna.UI2.WinForms.Guna2RadioButton();
            this.rdReason3 = new Guna.UI2.WinForms.Guna2RadioButton();
            this.rdReason2 = new Guna.UI2.WinForms.Guna2RadioButton();
            this.rdReason1 = new Guna.UI2.WinForms.Guna2RadioButton();
            this.lblTerm = new System.Windows.Forms.Label();
            this.lblReason = new System.Windows.Forms.Label();
            this.btnSubmit = new Guna.UI2.WinForms.Guna2Button();
            this.txtReason = new Guna.UI2.WinForms.Guna2TextBox();
            this.titleBar = new Guna.UI2.WinForms.Guna2Panel();
            this.lblSubTitle = new System.Windows.Forms.Label();
            this.lblTitle = new System.Windows.Forms.Label();
            this.cbClose = new Guna.UI2.WinForms.Guna2ControlBox();
            this.btnClose = new Guna.UI2.WinForms.Guna2Button();
            this.panelSignIn.SuspendLayout();
            this.titleBar.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelSignIn
            // 
            this.panelSignIn.BackColor = System.Drawing.Color.Transparent;
            this.panelSignIn.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.panelSignIn.BorderThickness = 2;
            this.panelSignIn.Controls.Add(this.rdReason6);
            this.panelSignIn.Controls.Add(this.rdReason5);
            this.panelSignIn.Controls.Add(this.rdReason4);
            this.panelSignIn.Controls.Add(this.rdReason3);
            this.panelSignIn.Controls.Add(this.rdReason2);
            this.panelSignIn.Controls.Add(this.rdReason1);
            this.panelSignIn.Controls.Add(this.lblTerm);
            this.panelSignIn.Controls.Add(this.lblReason);
            this.panelSignIn.Controls.Add(this.btnSubmit);
            this.panelSignIn.Controls.Add(this.txtReason);
            this.panelSignIn.Controls.Add(this.titleBar);
            this.panelSignIn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelSignIn.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panelSignIn.Location = new System.Drawing.Point(0, 0);
            this.panelSignIn.Margin = new System.Windows.Forms.Padding(2);
            this.panelSignIn.Name = "panelSignIn";
            this.panelSignIn.ShadowDecoration.BorderRadius = 20;
            this.panelSignIn.Size = new System.Drawing.Size(451, 559);
            this.panelSignIn.TabIndex = 2;
            this.panelSignIn.UseTransparentBackground = true;
            // 
            // rdReason6
            // 
            this.rdReason6.AutoSize = true;
            this.rdReason6.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(104)))), ((int)(((byte)(238)))));
            this.rdReason6.CheckedState.BorderThickness = 0;
            this.rdReason6.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(104)))), ((int)(((byte)(238)))));
            this.rdReason6.CheckedState.InnerColor = System.Drawing.Color.White;
            this.rdReason6.CheckedState.InnerOffset = -4;
            this.rdReason6.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdReason6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.rdReason6.Location = new System.Drawing.Point(50, 365);
            this.rdReason6.Name = "rdReason6";
            this.rdReason6.Size = new System.Drawing.Size(55, 19);
            this.rdReason6.TabIndex = 33;
            this.rdReason6.Text = "Other";
            this.rdReason6.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.rdReason6.UncheckedState.BorderThickness = 2;
            this.rdReason6.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.rdReason6.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            // 
            // rdReason5
            // 
            this.rdReason5.AutoSize = true;
            this.rdReason5.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(104)))), ((int)(((byte)(238)))));
            this.rdReason5.CheckedState.BorderThickness = 0;
            this.rdReason5.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(104)))), ((int)(((byte)(238)))));
            this.rdReason5.CheckedState.InnerColor = System.Drawing.Color.White;
            this.rdReason5.CheckedState.InnerOffset = -4;
            this.rdReason5.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdReason5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.rdReason5.Location = new System.Drawing.Point(50, 330);
            this.rdReason5.Name = "rdReason5";
            this.rdReason5.Size = new System.Drawing.Size(202, 19);
            this.rdReason5.TabIndex = 32;
            this.rdReason5.Text = "Postponement or Indefinite Delay";
            this.rdReason5.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.rdReason5.UncheckedState.BorderThickness = 2;
            this.rdReason5.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.rdReason5.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            // 
            // rdReason4
            // 
            this.rdReason4.AutoSize = true;
            this.rdReason4.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(104)))), ((int)(((byte)(238)))));
            this.rdReason4.CheckedState.BorderThickness = 0;
            this.rdReason4.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(104)))), ((int)(((byte)(238)))));
            this.rdReason4.CheckedState.InnerColor = System.Drawing.Color.White;
            this.rdReason4.CheckedState.InnerOffset = -4;
            this.rdReason4.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdReason4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.rdReason4.Location = new System.Drawing.Point(50, 295);
            this.rdReason4.Name = "rdReason4";
            this.rdReason4.Size = new System.Drawing.Size(94, 19);
            this.rdReason4.TabIndex = 31;
            this.rdReason4.Text = "Health Issues";
            this.rdReason4.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.rdReason4.UncheckedState.BorderThickness = 2;
            this.rdReason4.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.rdReason4.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            // 
            // rdReason3
            // 
            this.rdReason3.AutoSize = true;
            this.rdReason3.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(104)))), ((int)(((byte)(238)))));
            this.rdReason3.CheckedState.BorderThickness = 0;
            this.rdReason3.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(104)))), ((int)(((byte)(238)))));
            this.rdReason3.CheckedState.InnerColor = System.Drawing.Color.White;
            this.rdReason3.CheckedState.InnerOffset = -4;
            this.rdReason3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdReason3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.rdReason3.Location = new System.Drawing.Point(50, 260);
            this.rdReason3.Name = "rdReason3";
            this.rdReason3.Size = new System.Drawing.Size(150, 19);
            this.rdReason3.TabIndex = 30;
            this.rdReason3.Text = "Business Commitments";
            this.rdReason3.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.rdReason3.UncheckedState.BorderThickness = 2;
            this.rdReason3.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.rdReason3.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            // 
            // rdReason2
            // 
            this.rdReason2.AutoSize = true;
            this.rdReason2.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(104)))), ((int)(((byte)(238)))));
            this.rdReason2.CheckedState.BorderThickness = 0;
            this.rdReason2.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(104)))), ((int)(((byte)(238)))));
            this.rdReason2.CheckedState.InnerColor = System.Drawing.Color.White;
            this.rdReason2.CheckedState.InnerOffset = -4;
            this.rdReason2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdReason2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.rdReason2.Location = new System.Drawing.Point(50, 225);
            this.rdReason2.Name = "rdReason2";
            this.rdReason2.Size = new System.Drawing.Size(154, 19);
            this.rdReason2.TabIndex = 29;
            this.rdReason2.Text = "Financial Considerations";
            this.rdReason2.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.rdReason2.UncheckedState.BorderThickness = 2;
            this.rdReason2.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.rdReason2.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            // 
            // rdReason1
            // 
            this.rdReason1.AutoSize = true;
            this.rdReason1.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(104)))), ((int)(((byte)(238)))));
            this.rdReason1.CheckedState.BorderThickness = 0;
            this.rdReason1.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(104)))), ((int)(((byte)(238)))));
            this.rdReason1.CheckedState.InnerColor = System.Drawing.Color.White;
            this.rdReason1.CheckedState.InnerOffset = -4;
            this.rdReason1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdReason1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.rdReason1.Location = new System.Drawing.Point(50, 190);
            this.rdReason1.Name = "rdReason1";
            this.rdReason1.Size = new System.Drawing.Size(130, 19);
            this.rdReason1.TabIndex = 28;
            this.rdReason1.Text = "Change in Schedule";
            this.rdReason1.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.rdReason1.UncheckedState.BorderThickness = 2;
            this.rdReason1.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.rdReason1.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            // 
            // lblTerm
            // 
            this.lblTerm.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblTerm.AutoSize = true;
            this.lblTerm.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(135)))), ((int)(((byte)(145)))), ((int)(((byte)(180)))));
            this.lblTerm.Location = new System.Drawing.Point(89, 519);
            this.lblTerm.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTerm.Name = "lblTerm";
            this.lblTerm.Size = new System.Drawing.Size(266, 13);
            this.lblTerm.TabIndex = 3;
            this.lblTerm.Text = "We apologize by making you having a bad experience.";
            // 
            // lblReason
            // 
            this.lblReason.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblReason.AutoSize = true;
            this.lblReason.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReason.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(135)))), ((int)(((byte)(145)))), ((int)(((byte)(180)))));
            this.lblReason.Location = new System.Drawing.Point(50, 154);
            this.lblReason.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblReason.Name = "lblReason";
            this.lblReason.Size = new System.Drawing.Size(57, 20);
            this.lblReason.TabIndex = 20;
            this.lblReason.Text = "Reason";
            // 
            // btnSubmit
            // 
            this.btnSubmit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnSubmit.BackColor = System.Drawing.Color.White;
            this.btnSubmit.BorderRadius = 10;
            this.btnSubmit.BorderThickness = 1;
            this.btnSubmit.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnSubmit.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnSubmit.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnSubmit.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnSubmit.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(104)))), ((int)(((byte)(238)))));
            this.btnSubmit.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubmit.ForeColor = System.Drawing.Color.White;
            this.btnSubmit.Location = new System.Drawing.Point(51, 451);
            this.btnSubmit.Margin = new System.Windows.Forms.Padding(2);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(344, 42);
            this.btnSubmit.TabIndex = 14;
            this.btnSubmit.Text = "Confirm Cancellation";
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // txtReason
            // 
            this.txtReason.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtReason.BorderRadius = 10;
            this.txtReason.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtReason.DefaultText = "";
            this.txtReason.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtReason.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtReason.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtReason.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtReason.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtReason.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtReason.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtReason.Location = new System.Drawing.Point(48, 395);
            this.txtReason.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtReason.Name = "txtReason";
            this.txtReason.PasswordChar = '\0';
            this.txtReason.PlaceholderText = "Reason";
            this.txtReason.SelectedText = "";
            this.txtReason.Size = new System.Drawing.Size(347, 35);
            this.txtReason.TabIndex = 10;
            // 
            // titleBar
            // 
            this.titleBar.BackColor = System.Drawing.Color.Transparent;
            this.titleBar.Controls.Add(this.lblSubTitle);
            this.titleBar.Controls.Add(this.lblTitle);
            this.titleBar.Controls.Add(this.cbClose);
            this.titleBar.Controls.Add(this.btnClose);
            this.titleBar.Dock = System.Windows.Forms.DockStyle.Top;
            this.titleBar.Location = new System.Drawing.Point(0, 0);
            this.titleBar.Name = "titleBar";
            this.titleBar.Size = new System.Drawing.Size(451, 134);
            this.titleBar.TabIndex = 24;
            this.titleBar.MouseDown += new System.Windows.Forms.MouseEventHandler(this.guna2Panel2_MouseDown);
            // 
            // lblSubTitle
            // 
            this.lblSubTitle.AutoSize = true;
            this.lblSubTitle.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSubTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(135)))), ((int)(((byte)(145)))), ((int)(((byte)(180)))));
            this.lblSubTitle.Location = new System.Drawing.Point(50, 89);
            this.lblSubTitle.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblSubTitle.Name = "lblSubTitle";
            this.lblSubTitle.Size = new System.Drawing.Size(337, 20);
            this.lblSubTitle.TabIndex = 25;
            this.lblSubTitle.Text = "We will manage to make everything good for you";
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(135)))), ((int)(((byte)(145)))), ((int)(((byte)(180)))));
            this.lblTitle.Location = new System.Drawing.Point(44, 40);
            this.lblTitle.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(319, 40);
            this.lblTitle.TabIndex = 17;
            this.lblTitle.Text = "Please tell us a reason";
            // 
            // cbClose
            // 
            this.cbClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cbClose.BackColor = System.Drawing.Color.Transparent;
            this.cbClose.BorderRadius = 5;
            this.cbClose.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(104)))), ((int)(((byte)(238)))));
            this.cbClose.IconColor = System.Drawing.Color.White;
            this.cbClose.Location = new System.Drawing.Point(406, 0);
            this.cbClose.Name = "cbClose";
            this.cbClose.Size = new System.Drawing.Size(45, 29);
            this.cbClose.TabIndex = 23;
            // 
            // btnClose
            // 
            this.btnClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnClose.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnClose.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnClose.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnClose.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnClose.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnClose.ForeColor = System.Drawing.Color.White;
            this.btnClose.Location = new System.Drawing.Point(424, 4);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(15, 18);
            this.btnClose.TabIndex = 27;
            this.btnClose.Text = "guna2Button1";
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // FOrderReason
            // 
            this.AcceptButton = this.btnSubmit;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.CancelButton = this.btnClose;
            this.ClientSize = new System.Drawing.Size(451, 559);
            this.Controls.Add(this.panelSignIn);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FOrderReason";
            this.Text = "FOrder";
            this.panelSignIn.ResumeLayout(false);
            this.panelSignIn.PerformLayout();
            this.titleBar.ResumeLayout(false);
            this.titleBar.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2Panel panelSignIn;
        private Guna.UI2.WinForms.Guna2ControlBox cbClose;
        private System.Windows.Forms.Label lblTerm;
        private System.Windows.Forms.Label lblReason;
        private System.Windows.Forms.Label lblTitle;
        private Guna.UI2.WinForms.Guna2Button btnSubmit;
        private Guna.UI2.WinForms.Guna2TextBox txtReason;
        private Guna.UI2.WinForms.Guna2Panel titleBar;
        private System.Windows.Forms.Label lblSubTitle;
        private Guna.UI2.WinForms.Guna2RadioButton rdReason1;
        private Guna.UI2.WinForms.Guna2RadioButton rdReason6;
        private Guna.UI2.WinForms.Guna2RadioButton rdReason5;
        private Guna.UI2.WinForms.Guna2RadioButton rdReason4;
        private Guna.UI2.WinForms.Guna2RadioButton rdReason3;
        private Guna.UI2.WinForms.Guna2RadioButton rdReason2;
        private Guna.UI2.WinForms.Guna2Button btnClose;
    }
}